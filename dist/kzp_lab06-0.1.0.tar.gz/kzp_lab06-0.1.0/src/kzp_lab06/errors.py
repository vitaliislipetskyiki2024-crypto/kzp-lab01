class DataError(ValueError):
    """Помилка формату або значення вхідних даних."""